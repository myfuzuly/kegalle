<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Listing;
use App\Models\Store;

class HomeController extends Controller
{
    public function __invoke()
    {
        $categories = Category::where('is_active', 1)
            ->withCount(['listings' => fn($q) => $q->published()])
            ->orderBy('sort_order')
            ->orderBy('name')
            ->take(10)
            ->get();

        $featuredListings = Listing::published()
            ->with(['store','user','category','images'])
            ->where(function ($q) {
                $q->where('is_featured', true)->orWhere('is_top', true);
            })
            ->latest()
            ->take(10)
            ->get();

        if ($featuredListings->count() < 5) {
            $featuredListings = Listing::published()
                ->with(['store','user','category','images'])
                ->latest()
                ->take(10)
                ->get();
        }

        $featuredStores = Store::whereIn('status', ['approved', 'published', 'active'])
            ->withCount(['listings' => fn($q) => $q->published()])
            ->orderByDesc('is_featured')
            ->latest()
            ->take(8)
            ->get();

        return view('frontend.home', compact('categories', 'featuredListings', 'featuredStores'));
    }
}
