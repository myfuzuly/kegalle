<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Listing;
use App\Models\Store;
use Illuminate\Http\Request;

class ListingController extends Controller
{
    public function index(Request $request)
    {
        $query = Listing::published()->with(['store','user','category','images']);

        if ($request->filled('q')) {
            $keyword = trim($request->q);
            $query->where(function ($q) use ($keyword) {
                $q->where('title', 'like', "%{$keyword}%")
                  ->orWhere('description', 'like', "%{$keyword}%")
                  ->orWhere('location', 'like', "%{$keyword}%");
            });
        }

        if ($request->filled('type')) {
            $query->where('type', $request->type);
        }

        if ($request->filled('category')) {
            $query->whereHas('category', fn($q) => $q->where('slug', $request->category));
        }

        if ($request->filled('store')) {
            $query->whereHas('store', fn($q) => $q->where('slug', $request->store));
        }

        if ($request->filled('location')) {
            $query->where('location', 'like', '%' . trim($request->location) . '%');
        }

        if ($request->filled('min_price')) {
            $query->where('price', '>=', (float) $request->min_price);
        }

        if ($request->filled('max_price')) {
            $query->where('price', '<=', (float) $request->max_price);
        }

        match ($request->get('sort')) {
            'price_low' => $query->orderBy('price'),
            'price_high' => $query->orderByDesc('price'),
            'popular' => $query->orderByDesc('views'),
            default => $query->latest(),
        };

        return view('frontend.listings.index', [
            'listings' => $query->paginate(18)->withQueryString(),
            'categories' => Category::where('is_active', 1)->orderBy('name')->get(),
            'stores' => Store::whereIn('status', ['approved', 'published', 'active'])->orderBy('name')->take(50)->get(),
        ]);
    }

    public function show($slug)
    {
        $listing = Listing::published()
            ->where('slug', $slug)
            ->with(['store','user','category','images','values.field'])
            ->firstOrFail();

        $listing->increment('views');

        $related = Listing::published()
            ->with(['store','user','category','images'])
            ->where('id', '!=', $listing->id)
            ->when($listing->category_id, fn($q) => $q->where('category_id', $listing->category_id))
            ->latest()
            ->take(4)
            ->get();

        return view('frontend.listings.show', compact('listing', 'related'));
    }
}
