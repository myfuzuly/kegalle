<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\Store;
use Illuminate\Http\Request;

class StoreController extends Controller
{
    public function index(Request $request)
    {
        $query = Store::whereIn('status', ['approved', 'published', 'active'])
            ->withCount(['listings' => fn($q) => $q->published()]);

        if ($request->filled('q')) {
            $keyword = trim($request->q);
            $query->where(function ($q) use ($keyword) {
                $q->where('name', 'like', "%{$keyword}%")
                  ->orWhere('description', 'like', "%{$keyword}%")
                  ->orWhere('city', 'like', "%{$keyword}%")
                  ->orWhere('address', 'like', "%{$keyword}%");
            });
        }

        return view('frontend.stores.index', [
            'stores' => $query->orderByDesc('is_featured')->latest()->paginate(18)->withQueryString(),
        ]);
    }

    public function show($slug)
    {
        $store = Store::whereIn('status', ['approved', 'published', 'active'])
            ->where('slug', $slug)
            ->with(['user', 'listings' => fn($q) => $q->published()->with(['category','images'])->latest()])
            ->withCount(['listings' => fn($q) => $q->published()])
            ->firstOrFail();

        return view('frontend.stores.show', compact('store'));
    }
}
