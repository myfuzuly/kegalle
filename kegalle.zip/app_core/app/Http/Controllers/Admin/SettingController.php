<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller; use App\Models\User;
class SettingController extends Controller { public function index(){ return view('admin.settings.index',['items'=>User::latest()->take(100)->get()]); } }
