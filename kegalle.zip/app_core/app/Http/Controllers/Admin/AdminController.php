<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller; use App\Models\{User,Store,Listing,Payment,Review,ChatThread};
class AdminController extends Controller { public function index(){return view('admin.dashboard.index',['users'=>User::count(),'stores'=>Store::count(),'listings'=>Listing::count(),'pendingListings'=>Listing::where('status','pending')->count(),'payments'=>Payment::sum('amount'),'reviews'=>Review::count(),'chats'=>ChatThread::count()]);}}
