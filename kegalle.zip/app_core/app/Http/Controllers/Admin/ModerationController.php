<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller; use App\Models\{Store,Listing};
class ModerationController extends Controller { public function stores(){return view('admin.stores.index',['stores'=>Store::latest()->get()]);} public function listings(){return view('admin.listings.index',['listings'=>Listing::with('store','user')->latest()->get()]);} public function approveStore(Store $store){$store->update(['status'=>'approved']); return back();} public function approveListing(Listing $listing){$listing->update(['status'=>'published']); return back();} public function rejectListing(Listing $listing){$listing->update(['status'=>'rejected']); return back();}}
