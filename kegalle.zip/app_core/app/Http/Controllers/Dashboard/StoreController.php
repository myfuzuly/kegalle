<?php
namespace App\Http\Controllers\Dashboard;
use App\Http\Controllers\Controller; use App\Models\Store; use Illuminate\Http\Request; use Illuminate\Support\Str;
class StoreController extends Controller { public function index(){return view('dashboard.stores.index',['stores'=>auth()->user()->stores]);} public function create(){return view('dashboard.stores.form');} public function store(Request $r){$d=$r->validate(['name'=>'required','description'=>'nullable','phone'=>'nullable','email'=>'nullable|email','whatsapp'=>'nullable','address'=>'nullable','city'=>'nullable']); $d['user_id']=auth()->id(); $d['slug']=Str::slug($d['name']).'-'.Str::random(4); $d['status']='pending'; Store::create($d); return redirect('/dashboard/stores')->with('success','Store submitted for approval.');}}
