<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Listing extends Model
{
    protected $fillable = [
        'user_id','store_id','category_id','ad_type','type','title','slug','description','price','currency','condition','location','status','is_featured','is_top','is_urgent','bumped_at','expires_at','views'
    ];

    protected $casts = [
        'is_featured' => 'boolean',
        'is_top' => 'boolean',
        'is_urgent' => 'boolean',
        'bumped_at' => 'datetime',
        'expires_at' => 'datetime',
    ];

    public function getRouteKeyName(): string
    {
        return 'slug';
    }

    public function user(){ return $this->belongsTo(User::class); }
    public function store(){ return $this->belongsTo(Store::class); }
    public function category(){ return $this->belongsTo(Category::class); }
    public function images(){ return $this->hasMany(ListingImage::class)->orderBy('sort_order'); }
    public function values(){ return $this->hasMany(ListingFieldValue::class); }

    public function scopePublished($query)
    {
        return $query->whereIn('status', ['published', 'approved', 'active']);
    }

    public function sellerName(): ?string
    {
        return $this->store?->name ?? $this->user?->name;
    }

    public function primaryImage(): ?string
    {
        $path = $this->images->first()?->path;
        if (!$path) return null;
        return str_starts_with($path, 'http') ? $path : '/storage/' . ltrim($path, '/');
    }

    public function priceLabel(): string
    {
        if ($this->price === null) return 'Contact for price';
        return ($this->currency ?: 'LKR') . ' ' . number_format((float) $this->price, 0);
    }
}
