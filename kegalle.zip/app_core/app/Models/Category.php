<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    protected $fillable = ['parent_id','name','slug','type','icon','description','sort_order','is_active'];

    protected $casts = ['is_active' => 'boolean'];

    public function parent(){ return $this->belongsTo(Category::class,'parent_id'); }
    public function children(){ return $this->hasMany(Category::class,'parent_id'); }

    public function listings(){ return $this->hasMany(Listing::class, 'category_id'); }
    public function products(){ return $this->hasMany(Listing::class, 'category_id')->where('type', 'product'); }
    public function classifieds(){ return $this->hasMany(Listing::class, 'category_id')->where('type', 'classified'); }

    public function fields(){
        return $this->belongsToMany(CustomField::class,'category_custom_field')
            ->withPivot(['is_required','show_in_filter','show_in_list','sort_order']);
    }
}
