<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\Frontend\HomeController;
use App\Http\Controllers\Frontend\ListingController;
use App\Http\Controllers\Frontend\StoreController;

use App\Http\Controllers\Auth\AuthController;

use App\Http\Controllers\Dashboard\ListingController as DashListing;
use App\Http\Controllers\Dashboard\StoreController as DashStore;

use App\Http\Controllers\Admin\AdminController;
use App\Http\Controllers\Admin\ModerationController;
use App\Http\Controllers\Admin\CategoryController;
use App\Http\Controllers\Admin\CustomFieldController;
use App\Http\Controllers\Admin\MembershipController;
use App\Http\Controllers\Admin\PaymentController;
use App\Http\Controllers\Admin\ChatController;
use App\Http\Controllers\Admin\ReviewController;
use App\Http\Controllers\Admin\SettingController;

/*
|--------------------------------------------------------------------------
| Frontend Routes
|--------------------------------------------------------------------------
*/

Route::get('/', HomeController::class)->name('home');

Route::get('/stores', [StoreController::class, 'index'])->name('stores.index');
Route::get('/store/{slug}', [StoreController::class, 'show'])->name('stores.show');

Route::get('/listings', [ListingController::class, 'index'])->name('listings.index');
Route::get('/classified', [ListingController::class, 'index'])->name('classified.index');

// Listing detail routes: both URL styles are supported.
Route::get('/listing/{slug}', [ListingController::class, 'show'])->name('listing.show');
Route::get('/listings/{slug}', [ListingController::class, 'show'])->name('listings.show');

/*
|--------------------------------------------------------------------------
| Auth Routes
|--------------------------------------------------------------------------
*/

Route::get('/login', [AuthController::class, 'login'])->name('login');
Route::post('/login', [AuthController::class, 'doLogin'])->name('login.submit');

Route::get('/register', [AuthController::class, 'register'])->name('register');
Route::post('/register', [AuthController::class, 'doRegister'])->name('register.submit');

Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

/*
|--------------------------------------------------------------------------
| User Dashboard Routes
|--------------------------------------------------------------------------
*/

Route::middleware('auth')->prefix('dashboard')->group(function () {
    Route::view('/', 'dashboard.index')->name('dashboard');

    Route::get('/stores', [DashStore::class, 'index'])->name('dashboard.stores.index');
    Route::get('/stores/create', [DashStore::class, 'create'])->name('dashboard.stores.create');
    Route::post('/stores', [DashStore::class, 'store'])->name('dashboard.stores.store');

    Route::get('/listings', [DashListing::class, 'index'])->name('dashboard.listings.index');
    Route::get('/listings/create', [DashListing::class, 'create'])->name('dashboard.listings.create');
    Route::post('/listings', [DashListing::class, 'store'])->name('dashboard.listings.store');

    Route::view('/membership', 'dashboard.memberships.index')->name('dashboard.membership');
    Route::view('/payments', 'dashboard.payments.index')->name('dashboard.payments');
    Route::view('/chat', 'dashboard.chats.index')->name('dashboard.chat');
    Route::view('/reviews', 'dashboard.reviews.index')->name('dashboard.reviews');
});

/*
|--------------------------------------------------------------------------
| Admin Routes
|--------------------------------------------------------------------------
*/

Route::prefix('admin')->middleware('auth')->group(function () {
    Route::get('/', [AdminController::class, 'index'])->name('admin.index');

    Route::get('/stores', [ModerationController::class, 'stores'])->name('admin.stores.index');
    Route::post('/stores/{store}/approve', [ModerationController::class, 'approveStore'])->name('admin.stores.approve');

    Route::get('/listings', [ModerationController::class, 'listings'])->name('admin.listings.index');
    Route::post('/listings/{listing}/approve', [ModerationController::class, 'approveListing'])->name('admin.listings.approve');
    Route::post('/listings/{listing}/reject', [ModerationController::class, 'rejectListing'])->name('admin.listings.reject');

    Route::get('/categories', [CategoryController::class, 'index'])->name('admin.categories.index');
    Route::post('/categories', [CategoryController::class, 'store'])->name('admin.categories.store');

    Route::get('/fields', [CustomFieldController::class, 'index'])->name('admin.fields.index');
    Route::post('/fields', [CustomFieldController::class, 'store'])->name('admin.fields.store');

    Route::get('/memberships', [MembershipController::class, 'index'])->name('admin.memberships.index');
    Route::post('/memberships', [MembershipController::class, 'store'])->name('admin.memberships.store');

    Route::get('/payments', [PaymentController::class, 'index'])->name('admin.payments.index');
    Route::get('/chats', [ChatController::class, 'index'])->name('admin.chats.index');
    Route::get('/reviews', [ReviewController::class, 'index'])->name('admin.reviews.index');
    Route::get('/settings', [SettingController::class, 'index'])->name('admin.settings.index');
});
