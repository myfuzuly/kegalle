@extends('layouts.app')
@section('title','Stores - Kegalle')
@section('content')
<section class="kg-page-head"><div class="kg-container"><h1>Store Directory</h1><p>Discover verified business stores and their products.</p><form class="kg-inline-search" method="get"><input name="q" value="{{ request('q') }}" placeholder="Search store name, city or business"><button>Search</button></form></div></section>
<section class="kg-container kg-section"><div class="kg-store-grid">@forelse($stores as $store)<a class="kg-store-card" href="/store/{{ $store->slug }}"><div class="kg-store-logo">@if($store->logo)<img src="/storage/{{ $store->logo }}" alt="{{ $store->name }}">@else{{ strtoupper(substr($store->name,0,1)) }}@endif</div><h3>{{ $store->name }}</h3><p>{{ $store->city ?: 'Kegalle' }}</p><small>{{ $store->listings_count }} Products · Verified</small><span>View Store</span></a>@empty<div class="kg-empty">No approved stores found.</div>@endforelse</div><div class="kg-pagination">{{ $stores->links() }}</div></section>
@endsection
