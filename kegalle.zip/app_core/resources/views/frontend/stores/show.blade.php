@extends('layouts.app')

@section('title', ($store->name ?? 'Store') . ' - Kegalle')

@section('content')
<section class="ks-store-wrap">
    <div class="ks-store-hero">
        <div class="kg-container ks-store-hero-inner">
            <div class="ks-store-brand-card">
                <div class="ks-store-logo-xl">
                    @if(!empty($store->logo))
                        <img src="/storage/{{ $store->logo }}" alt="{{ $store->name }}">
                    @else
                        {{ strtoupper(substr($store->name ?? 'S', 0, 1)) }}
                    @endif
                </div>

                <div>
                    <div class="ks-badges">
                        <span>✓ Verified Store</span>
                        <span>{{ $store->listings_count ?? $store->products_count ?? 0 }} Listings</span>
                    </div>
                    <h1>{{ $store->name }}</h1>
                    <p>{{ $store->description ?? 'Trusted local store on Kegalle marketplace.' }}</p>
                    <div class="ks-store-meta">
                        <span>📍 {{ $store->city ?? $store->address ?? 'Kegalle' }}</span>
                        @if(!empty($store->phone))<span>📞 {{ $store->phone }}</span>@endif
                        @if(!empty($store->email))<span>✉ {{ $store->email }}</span>@endif
                    </div>
                </div>
            </div>

            <aside class="ks-contact-panel">
                <h3>Contact Store</h3>
                <p>Ask about availability, pricing, delivery or bulk orders.</p>
                @if(!empty($store->phone))
                    <a class="ks-primary-btn" href="tel:{{ $store->phone }}">Call Store</a>
                    <a class="ks-whatsapp-btn" target="_blank" href="https://wa.me/{{ preg_replace('/[^0-9]/','',$store->phone) }}">WhatsApp</a>
                @else
                    <a class="ks-primary-btn" href="#">Send Enquiry</a>
                @endif
                <button class="ks-light-btn" type="button" onclick="navigator.share ? navigator.share({title:'{{ $store->name }}',url:window.location.href}) : navigator.clipboard.writeText(window.location.href)">Share Store</button>
            </aside>
        </div>
    </div>

    <div class="kg-container ks-store-body">
        <main>
            <section class="ks-card ks-about-card">
                <div class="ks-section-title">
                    <span>About Store</span>
                    <h2>Business Information</h2>
                </div>
                <p>{{ $store->description ?? 'This store has not added a detailed description yet.' }}</p>
                <div class="ks-info-grid">
                    <div><b>Location</b><span>{{ $store->city ?? $store->address ?? 'Kegalle' }}</span></div>
                    <div><b>Status</b><span>Verified / Active</span></div>
                    <div><b>Products</b><span>{{ $store->listings_count ?? $store->products_count ?? 0 }}</span></div>
                    <div><b>Marketplace</b><span>Kegalle</span></div>
                </div>
            </section>

            <section class="ks-card ks-products-card">
                <div class="ks-section-title ks-title-row">
                    <div>
                        <span>Store Catalogue</span>
                        <h2>Products & Listings</h2>
                    </div>
                    <a href="/listings?store={{ $store->slug }}">View All →</a>
                </div>

                @php
                    $storeListings = $listings ?? $products ?? ($store->listings ?? collect());
                @endphp

                @if($storeListings->count())
                    <div class="ks-product-grid">
                        @foreach($storeListings as $listing)
                            <a class="ks-product-card" href="/listings/{{ $listing->slug }}">
                                <div class="ks-product-img">
                                    @if(isset($listing->images) && $listing->images->count())
                                        <img src="/storage/{{ $listing->images->first()->path }}" alt="{{ $listing->title }}">
                                    @else
                                        <span>{{ strtoupper(substr($listing->title,0,1)) }}</span>
                                    @endif
                                    @if(!empty($listing->is_featured))<em>Featured</em>@endif
                                </div>
                                <div class="ks-product-info">
                                    <small>{{ $listing->category->name ?? 'General' }}</small>
                                    <h3>{{ $listing->title }}</h3>
                                    <strong>LKR {{ number_format($listing->price ?? 0) }}</strong>
                                    <p>📍 {{ $listing->location ?? ($store->city ?? 'Kegalle') }}</p>
                                </div>
                            </a>
                        @endforeach
                    </div>
                @else
                    <div class="ks-empty">No approved listings found for this store yet.</div>
                @endif
            </section>
        </main>

        <aside class="ks-sidebar">
            <div class="ks-card ks-trust-card">
                <h3>Why buyers trust this store</h3>
                <ul>
                    <li>Verified local business profile</li>
                    <li>Direct phone / WhatsApp contact</li>
                    <li>Public product catalogue</li>
                    <li>Kegalle marketplace visibility</li>
                </ul>
            </div>

            <div class="ks-card ks-mini-contact">
                <h3>Store Details</h3>
                <p><b>Address:</b><br>{{ $store->address ?? 'Kegalle, Sri Lanka' }}</p>
                @if(!empty($store->phone))<p><b>Phone:</b><br>{{ $store->phone }}</p>@endif
                @if(!empty($store->email))<p><b>Email:</b><br>{{ $store->email }}</p>@endif
            </div>
        </aside>
    </div>
</section>
@endsection
