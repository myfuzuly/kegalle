@extends('layouts.app')
@section('title','Products & Ads - Kegalle')
@section('content')
<section class="kg-page-head"><div class="kg-container"><h1>Products & Classified Ads</h1><p>Browse live listings from stores and individual sellers.</p></div></section>
<div class="kg-container kg-listing-layout">
    <aside class="kg-filter">
        <h3>Filter Search</h3>
        <form method="get" action="/listings">
            <input name="q" value="{{ request('q') }}" placeholder="Keyword">
            <select name="category"><option value="">All Categories</option>@foreach($categories as $category)<option value="{{ $category->slug }}" @selected(request('category')==$category->slug)>{{ $category->name }}</option>@endforeach</select>
            <select name="store"><option value="">All Stores</option>@foreach($stores as $store)<option value="{{ $store->slug }}" @selected(request('store')==$store->slug)>{{ $store->name }}</option>@endforeach</select>
            <input name="location" value="{{ request('location') }}" placeholder="Location">
            <div class="kg-price-filter"><input name="min_price" value="{{ request('min_price') }}" placeholder="Min"><input name="max_price" value="{{ request('max_price') }}" placeholder="Max"></div>
            <select name="sort"><option value="">Latest</option><option value="popular" @selected(request('sort')=='popular')>Popular</option><option value="price_low" @selected(request('sort')=='price_low')>Price low to high</option><option value="price_high" @selected(request('sort')=='price_high')>Price high to low</option></select>
            <button>Apply Filter</button>
        </form>
    </aside>
    <section class="kg-results">
        <div class="kg-section-head"><h2>{{ $listings->total() }} Results</h2><a href="/listings">Clear Filter</a></div>
        <div class="kg-grid">
            @forelse($listings as $listing)
                @include('frontend.listings.card',['listing'=>$listing])
            @empty
                <div class="kg-empty">No matching listings found.</div>
            @endforelse
        </div>
        <div class="kg-pagination">{{ $listings->links() }}</div>
    </section>
</div>
@endsection
