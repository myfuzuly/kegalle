<a class="kg-listing-card" href="/listings/{{ $listing->slug }}">
    <div class="kg-listing-image">
        @php $firstImage = $listing->images->first()->path ?? $listing->image ?? null; @endphp
        @if($firstImage)
            <img loading="lazy" src="/storage/{{ $firstImage }}" alt="{{ $listing->title }}">
        @else
            <div class="kg-image-placeholder">{{ strtoupper(substr($listing->title,0,1)) }}</div>
        @endif
        <div class="kg-card-badges">
            <span class="kg-badge">{{ ucfirst($listing->type ?? 'Listing') }}</span>
            @if($listing->is_featured)<span class="kg-badge kg-badge-yellow">Featured</span>@endif
        </div>
        <button class="kg-save-btn" data-save-listing="{{ $listing->id }}" aria-label="Save listing">♡</button>
    </div>
    <div class="kg-listing-body">
        <small>{{ $listing->category->name ?? 'General' }}</small>
        <h3>{{ $listing->title }}</h3>
        <p>🕒 {{ $listing->created_at?->diffForHumans() }}</p>
        <p>📍 {{ $listing->location ?? 'Kegalle' }}</p>
        <p>🏬 {{ $listing->store->name ?? $listing->user->name ?? 'Seller' }}</p>
        <strong class="kg-price">LKR {{ number_format($listing->price ?? 0) }}</strong>
        <div class="kg-card-actions">
            <span class="kg-mini-cta call">View Details</span>
            <span class="kg-mini-cta wa">WhatsApp</span>
        </div>
    </div>
</a>
