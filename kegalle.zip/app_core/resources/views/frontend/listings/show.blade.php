@extends('layouts.app')

@section('title', ($listing->title ?? 'Listing') . ' - Kegalle')

@section('content')
@php
    $sellerName = $listing->store->name ?? $listing->user->name ?? 'Seller';
    $sellerPhone = $listing->store->phone ?? $listing->user->phone ?? null;
    $sellerLocation = $listing->store->city ?? $listing->store->address ?? $listing->location ?? 'Kegalle';
    $whatsapp = $sellerPhone ? preg_replace('/[^0-9]/', '', $sellerPhone) : null;
    $mainImage = optional($listing->images ?? collect())->first();
@endphp

<section class="pd-wrap">
    <div class="kg-container pd-breadcrumb">
        <a href="/">Home</a><span>/</span><a href="/listings">Listings</a><span>/</span><strong>{{ $listing->title }}</strong>
    </div>

    <div class="kg-container pd-grid">
        <main class="pd-main">
            <section class="pd-gallery-card">
                <div class="pd-main-image">
                    @if($mainImage)
                        <img src="/storage/{{ $mainImage->path ?? $mainImage->image ?? $mainImage->filename }}" alt="{{ $listing->title }}">
                    @else
                        <div class="pd-placeholder">{{ strtoupper(substr($listing->title, 0, 1)) }}</div>
                    @endif

                    <div class="pd-floating-badges">
                        <span>{{ ucfirst($listing->type ?? 'Listing') }}</span>
                        @if($listing->is_featured)<span class="pd-gold">Featured</span>@endif
                    </div>
                </div>

                @if(($listing->images ?? collect())->count() > 1)
                    <div class="pd-thumbs">
                        @foreach($listing->images->take(5) as $image)
                            <img src="/storage/{{ $image->path ?? $image->image ?? $image->filename }}" alt="{{ $listing->title }}">
                        @endforeach
                    </div>
                @endif
            </section>

            <section class="pd-card pd-title-card">
                <div class="pd-category-row">
                    <span>{{ $listing->category->name ?? 'General' }}</span>
                    <span>{{ $listing->created_at?->diffForHumans() }}</span>
                </div>
                <h1>{{ $listing->title }}</h1>
                <div class="pd-price">LKR {{ number_format($listing->price ?? 0) }}</div>
                <div class="pd-meta-grid">
                    <div><b>Location</b><span>{{ $listing->location ?? 'Kegalle' }}</span></div>
                    <div><b>Type</b><span>{{ ucfirst($listing->type ?? 'Listing') }}</span></div>
                    <div><b>Status</b><span>{{ ucfirst($listing->status ?? 'Approved') }}</span></div>
                    <div><b>Seller</b><span>{{ $sellerName }}</span></div>
                </div>
            </section>

            <section class="pd-card">
                <h2>Description</h2>
                <div class="pd-description">
                    {!! nl2br(e($listing->description ?? 'No description provided.')) !!}
                </div>
            </section>

            <section class="pd-card">
                <h2>Product / Listing Details</h2>
                <div class="pd-specs">
                    <div><strong>Category</strong><span>{{ $listing->category->name ?? 'General' }}</span></div>
                    <div><strong>Price</strong><span>LKR {{ number_format($listing->price ?? 0) }}</span></div>
                    <div><strong>Location</strong><span>{{ $listing->location ?? 'Kegalle' }}</span></div>
                    <div><strong>Published</strong><span>{{ $listing->created_at?->format('d M Y') }}</span></div>
                </div>
            </section>

            @if(isset($related) && $related->count())
                <section class="pd-card">
                    <div class="pd-section-head">
                        <h2>Similar Listings</h2>
                        <a href="/listings">View all</a>
                    </div>
                    <div class="pd-related-grid">
                        @foreach($related as $relatedItem)
                            @include('frontend.listings.card', ['listing' => $relatedItem])
                        @endforeach
                    </div>
                </section>
            @endif
        </main>

        <aside class="pd-sidebar">
            <section class="pd-seller-card">
                <div class="pd-seller-logo">
                    @if($listing->store && $listing->store->logo)
                        <img src="/storage/{{ $listing->store->logo }}" alt="{{ $listing->store->name }}">
                    @else
                        {{ strtoupper(substr($sellerName, 0, 1)) }}
                    @endif
                </div>

                <h3>{{ $sellerName }}</h3>
                <p>{{ $listing->store ? 'Verified Store' : 'Individual Seller' }}</p>
                <p class="pd-location">📍 {{ $sellerLocation }}</p>

                @if($sellerPhone)
                    <a class="pd-btn pd-call" href="tel:{{ $sellerPhone }}">Call Seller</a>
                    @if($whatsapp)
                        <a class="pd-btn pd-wa" href="https://wa.me/{{ $whatsapp }}?text={{ urlencode('Hi, I am interested in: '.$listing->title) }}" target="_blank">WhatsApp Seller</a>
                    @endif
                @else
                    <a class="pd-btn pd-call" href="#">Contact Seller</a>
                @endif

                @if($listing->store)
                    <a class="pd-btn pd-outline" href="/store/{{ $listing->store->slug }}">View Store Website</a>
                @endif
            </section>

            <section class="pd-side-card">
                <h3>Why buy through Kegalle?</h3>
                <ul>
                    <li>Verified local sellers and stores</li>
                    <li>Direct phone and WhatsApp contact</li>
                    <li>Location-focused marketplace</li>
                    <li>Simple product discovery</li>
                </ul>
            </section>

            <section class="pd-side-card pd-warning">
                <h3>Safety Tips</h3>
                <ul>
                    <li>Meet in a safe public place.</li>
                    <li>Inspect the item before payment.</li>
                    <li>Avoid advance payment to unknown sellers.</li>
                    <li>Report suspicious listings.</li>
                </ul>
            </section>
        </aside>
    </div>
</section>
@endsection
