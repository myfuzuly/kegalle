@extends('layouts.app')
@section('title','Kegalle - Buy, Sell & Discover')
@section('content')
<section class="kg-hero kg-premium-hero">
    <div class="kg-container kg-hero-grid">
        <div class="kg-hero-content">
            <span class="kg-eyebrow">Kegalle’s local marketplace</span>
            <h1>Find products, stores and deals <span>near you.</span></h1>
            <p>Search trusted local stores, business suppliers, everyday products and classified ads from verified sellers in Kegalle.</p>
            <form class="kg-search kg-search-premium" action="/listings" method="get">
                <select name="category"><option value="">All Categories</option>@foreach($categories as $category)<option value="{{ $category->slug }}">{{ $category->name }}</option>@endforeach</select>
                <input name="q" placeholder="Search products, stores or ads">
                <input name="location" placeholder="Location">
                <button>Search</button>
            </form>
            <div class="kg-popular"><b>Popular:</b><a href="/listings?q=Mobile">Mobiles</a><a href="/listings?q=Vehicle">Vehicles</a><a href="/listings?q=Property">Property</a><a href="/listings?q=Jobs">Jobs</a><a href="/stores">Stores</a></div>
        </div>
        <aside class="kg-join-card kg-stats-card">
            <h3>Grow your business online</h3>
            <p>Create a store profile and showcase all products with one shareable URL.</p>
            <a href="/register">+ Start Selling</a>
            <div class="kg-mini-stats"><strong>{{ $featuredListings->count() }}+</strong><small>Featured Ads</small><strong>{{ $featuredStores->count() }}+</strong><small>Stores</small></div>
        </aside>
    </div>
</section>

<section class="kg-container kg-categories kg-category-row">
    @forelse($categories as $category)
        <a href="/listings?category={{ $category->slug }}"><span>{{ $category->icon ?: '🛒' }}</span><b>{{ $category->name }}</b><small>{{ $category->listings_count }} Ads</small></a>
    @empty
        <p class="kg-empty">No categories yet. Add categories from admin panel.</p>
    @endforelse
</section>

<section class="kg-container kg-section kg-trust-row">
    <article><b>✓</b><span>Verified local stores</span></article>
    <article><b>⚡</b><span>Fast product discovery</span></article>
    <article><b>💬</b><span>Direct seller contact</span></article>
    <article><b>📍</b><span>Kegalle focused listings</span></article>
</section>

<section class="kg-container kg-section">
    <div class="kg-section-head"><div><span class="kg-small-title">Fresh marketplace picks</span><h2>Featured Products & Ads</h2></div><a href="/listings">View All →</a></div>
    <div class="kg-grid kg-premium-grid">
        @forelse($featuredListings as $listing)
            @include('frontend.listings.card',['listing'=>$listing])
        @empty
            <div class="kg-empty">No approved products or ads found.</div>
        @endforelse
    </div>
</section>

<section class="kg-container kg-section">
    <div class="kg-section-head"><div><span class="kg-small-title">Trusted vendors</span><h2>Featured Stores</h2></div><a href="/stores">View Stores →</a></div>
    <div class="kg-store-grid kg-premium-store-grid">
        @forelse($featuredStores as $store)
            <a class="kg-store-card kg-store-premium" href="/store/{{ $store->slug }}">
                <div class="kg-store-logo">@if($store->logo)<img src="/storage/{{ $store->logo }}" alt="{{ $store->name }}">@else{{ strtoupper(substr($store->name,0,1)) }}@endif</div>
                <h3>{{ $store->name }}</h3>
                <p>{{ $store->city ?: $store->address ?: 'Kegalle' }}</p>
                <small>Verified Store · {{ $store->listings_count }} Products</small>
                <span>Visit Store</span>
            </a>
        @empty
            <div class="kg-empty">No approved stores found.</div>
        @endforelse
    </div>
</section>

<section class="kg-container kg-how kg-premium-how"><h2>How Kegalle Works</h2><div><article><b>1</b><h3>Search</h3><p>Find local products, stores and ads.</p></article><article><b>2</b><h3>Compare</h3><p>Check seller details, pricing and location.</p></article><article><b>3</b><h3>Contact</h3><p>Call, WhatsApp or message the seller.</p></article><article><b>4</b><h3>Deal</h3><p>Buy and sell safely in your area.</p></article></div></section>
<section class="kg-container kg-app-banner"><div><span>For sellers and stores</span><h2>Turn your store into a simple online catalogue.</h2><p>Show your store profile, products, contact details and location with one public URL.</p><a href="/register">Create Store / Post Ad</a></div></section>
@endsection
