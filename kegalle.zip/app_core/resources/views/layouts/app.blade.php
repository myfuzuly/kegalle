<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>@yield('title','Kegalle')</title>
    <meta name="description" content="Kegalle local store and classified marketplace">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="/css/app.css?v=5001">
    <link rel="stylesheet" href="/css/kegalle-dynamic.css?v=5001">
    <link rel="stylesheet" href="/css/kegalle-all-ads.css?v=5001">
    <link rel="stylesheet" href="/css/kegalle-details-premium.css?v=5001">
    <link rel="stylesheet" href="/css/kegalle-store-detail.css?v=5001">
    <link rel="stylesheet" href="/css/kegalle-gallery-related.css?v=5001">
    <link rel="stylesheet" href="/css/kegalle-ux-upgrade-v4.css?v=5001">

    <script defer src="/js/app.js?v=5001"></script>
    <script defer src="/js/kegalle-premium.js?v=5001"></script>
    <script defer src="/js/kegalle-ux-upgrade-v4.js?v=5001"></script>
</head>
<body>
<header class="kg-header">
    <div class="kg-top-strip">
        <div class="kg-container kg-strip-inner">
            <span>📍 Kegalle local marketplace</span>
            <span>Trusted stores · Products · Classified ads</span>
        </div>
    </div>
    <div class="kg-container kg-nav">
        <a class="kg-brand" href="/">
            <span class="kg-mark">K</span>
            <span><strong>Kegalle</strong><small>Buy · Sell · Discover</small></span>
        </a>
        <nav class="kg-menu" data-nav-menu>
            <a href="/">Home</a>
            <a href="/stores">Stores</a>
            <a href="/classified">Classified</a>
            <a href="/listings?type=product">Products</a>
            @auth
                <a href="/dashboard">Dashboard</a>
                <form method="post" action="/logout">@csrf<button class="kg-link-btn">Logout</button></form>
            @else
                <a href="/login">Login</a>
                <a class="kg-post" href="/register">+ Post Free Ad</a>
            @endauth
        </nav>
        <button class="kg-mobile-toggle" data-mobile-menu aria-label="Menu">☰</button>
    </div>
</header>

<main>
    @if(session('success'))
        <div class="kg-container"><div class="kg-notice">{{ session('success') }}</div></div>
    @endif
    @yield('content')
</main>

<footer class="kg-footer">
    <div class="kg-container kg-footer-grid">
        <div>
            <h2>Kegalle</h2>
            <p>A premium local marketplace for shops, businesses, products and classified ads across Kegalle.</p>
            <div class="kg-social"><span>f</span><span>in</span><span>wa</span></div>
        </div>
        <div><h4>Marketplace</h4><a href="/listings">All Listings</a><a href="/stores">Stores</a><a href="/classified">Classified</a><a href="/listings?type=product">Products</a></div>
        <div><h4>Support</h4><a href="#">Help Center</a><a href="#">Safety Tips</a><a href="#">Terms</a><a href="#">Privacy Policy</a></div>
        <div><h4>Start Selling</h4><p>Open your store page or post a classified ad in minutes.</p><a class="kg-footer-btn" href="/register">Post Your Ad</a></div>
    </div>
    <div class="kg-container kg-copy">© {{ date('Y') }} Kegalle. All rights reserved.</div>
</footer>

<nav class="kg-mobile-actionbar" aria-label="Mobile quick actions">
    <a href="/listings">🔎 Search</a>
    <a href="/stores">🏬 Stores</a>
    <a href="/register">＋ Post</a>
</nav>
</body>
</html>
