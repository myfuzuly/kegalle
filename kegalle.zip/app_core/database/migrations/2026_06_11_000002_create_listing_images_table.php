<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (!Schema::hasTable('listing_images')) {
            Schema::create('listing_images', function (Blueprint $table) {
                $table->id();
                $table->foreignId('listing_id')->constrained('listings')->cascadeOnDelete();
                $table->string('path');
                $table->unsignedInteger('sort_order')->default(0);
                $table->boolean('is_primary')->default(false);
                $table->timestamps();
            });
            return;
        }

        Schema::table('listing_images', function (Blueprint $table) {
            if (!Schema::hasColumn('listing_images', 'is_primary')) {
                $table->boolean('is_primary')->default(false)->after('sort_order');
            }
        });
    }

    public function down(): void
    {
        // Keep table for safety during production rollbacks.
    }
};
