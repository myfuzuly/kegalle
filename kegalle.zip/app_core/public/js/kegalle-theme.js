document.addEventListener('click',function(e){const btn=e.target.closest('[data-km-menu]');if(btn){const links=document.querySelector('[data-km-links]');if(links)links.classList.toggle('open');}});
