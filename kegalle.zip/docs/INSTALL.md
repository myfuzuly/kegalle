# Kegalle Premium Full Build - Deployment

Upload and extract this ZIP into `/home/kurulla`.

Expected structure:

```
/home/kurulla/app_core
/home/kurulla/public_html
```

Run:

```bash
cd /home/kurulla/app_core
composer install --no-dev --optimize-autoloader
cp .env.example .env # only if .env does not already exist
php artisan key:generate --force # only for a new install
php artisan migrate --force
php artisan storage:link
php artisan optimize:clear
php artisan view:clear
```

Permissions:

```bash
chown -R kurulla:kurulla /home/kurulla/app_core /home/kurulla/public_html
chmod -R 775 /home/kurulla/app_core/storage /home/kurulla/app_core/bootstrap/cache
find /home/kurulla/public_html -type d -exec chmod 755 {} \;
find /home/kurulla/public_html -type f -exec chmod 644 {} \;
```

Admin URL:

```
https://kurulla.com/admin
```

Recommended admin:

```
admin@kurulla.com
Admin@123456
```

Change password immediately after login.
