<?php
use Illuminate\Http\Request;
define('LARAVEL_START', microtime(true));
$base = dirname(__DIR__).'/app_core';
require $base.'/vendor/autoload.php';
$app = require_once $base.'/bootstrap/app.php';
$app->handleRequest(Request::capture());
