(function(){
  document.addEventListener('click',function(e){
    const save=e.target.closest('[data-save-listing]');
    if(save){e.preventDefault(); save.classList.toggle('is-saved'); try{let id=save.dataset.saveListing;let s=JSON.parse(localStorage.getItem('kg_saved')||'[]');s=s.includes(id)?s.filter(x=>x!==id):[...s,id];localStorage.setItem('kg_saved',JSON.stringify(s));}catch(_){} }
    const thumb=e.target.closest('[data-gallery-thumb]');
    if(thumb){e.preventDefault();const img=document.querySelector('[data-gallery-main]');if(img){img.src=thumb.dataset.src;document.querySelectorAll('[data-gallery-thumb]').forEach(b=>b.classList.remove('is-active'));thumb.classList.add('is-active');}}
    const main=e.target.closest('[data-gallery-main]');
    if(main){const modal=document.querySelector('[data-zoom-modal]');const zoom=document.querySelector('[data-zoom-img]'); if(modal&&zoom){zoom.src=main.src;modal.classList.add('is-open');}}
    if(e.target.closest('[data-zoom-close]')||e.target.matches('[data-zoom-modal]')){document.querySelector('[data-zoom-modal]')?.classList.remove('is-open');}
    const car=e.target.closest('[data-carousel]');
    if(car){const target=document.querySelector(car.dataset.carousel); if(target){target.scrollBy({left:car.dataset.dir==='next'?320:-320,behavior:'smooth'});}}
  });
  const filterForm=document.querySelector('[data-ajax-filter]');
  if(filterForm){let timer; filterForm.addEventListener('input',()=>{clearTimeout(timer);timer=setTimeout(()=>filterForm.requestSubmit(),350)}); filterForm.addEventListener('submit',async function(e){e.preventDefault();const grid=document.querySelector('[data-listings-grid]');if(!grid)return;grid.classList.add('is-loading');const url=this.action+'?'+new URLSearchParams(new FormData(this)).toString();history.replaceState(null,'',url);try{const res=await fetch(url,{headers:{'X-Requested-With':'XMLHttpRequest'}});const html=await res.text();const doc=new DOMParser().parseFromString(html,'text/html');const fresh=doc.querySelector('[data-listings-grid]');const count=doc.querySelector('[data-results-count]');if(fresh)grid.innerHTML=fresh.innerHTML;if(count&&document.querySelector('[data-results-count]'))document.querySelector('[data-results-count]').innerHTML=count.innerHTML;}catch(err){console.warn(err)}finally{grid.classList.remove('is-loading');}})}
  try{const viewed=JSON.parse(localStorage.getItem('kg_recent')||'[]');const meta=document.querySelector('[data-current-listing]');if(meta){const item={id:meta.dataset.id,title:meta.dataset.title,url:location.pathname};localStorage.setItem('kg_recent',JSON.stringify([item,...viewed.filter(x=>x.id!==item.id)].slice(0,8)));}}
  catch(_){}
})();
