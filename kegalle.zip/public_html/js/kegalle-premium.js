document.addEventListener('DOMContentLoaded', function () {
  const btn = document.querySelector('[data-mobile-menu]');
  const menu = document.querySelector('[data-nav-menu]');
  if (btn && menu) {
    btn.addEventListener('click', function () {
      menu.classList.toggle('is-open');
    });
  }
});
