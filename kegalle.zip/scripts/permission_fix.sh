#!/bin/bash
cd ~/app_core && chmod -R 775 storage bootstrap/cache
