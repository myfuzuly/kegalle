#!/bin/bash
cd ~/app_core && php artisan migrate --seed
