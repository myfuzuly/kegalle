#!/bin/bash
cd ~/app_core && php artisan optimize
