# Production Checklist

- Set APP_ENV=production
- Set APP_DEBUG=false
- Change seeded admin password
- Configure mail driver
- Configure payment gateway credentials
- Add privacy policy and terms
- Configure backups
- Enable SSL
- Set cron for Laravel scheduler if queues/subscriptions are expanded
