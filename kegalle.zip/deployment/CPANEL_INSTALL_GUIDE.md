# cPanel Installation

1. Upload this ZIP to your cPanel home directory and extract it.
2. You should have `/home/USERNAME/app_core` and `/home/USERNAME/public_html`.
3. Create a MySQL database and user in cPanel, then assign all privileges.
4. Copy `app_core/.env.example` to `app_core/.env` and update APP_URL and DB values.
5. Open Terminal:

```bash
cd ~/app_core
composer install --no-dev --optimize-autoloader
php artisan key:generate
php artisan migrate --seed
php artisan storage:link
php artisan optimize
```

6. Make sure `public_html/index.php` points to `../app_core`.
7. Visit your domain.

If you get 500 error:

```bash
cd ~/app_core
php artisan optimize:clear
chmod -R 775 storage bootstrap/cache
```
