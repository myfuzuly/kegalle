USE kurulla_kegalle;

INSERT IGNORE INTO categories (name, slug, type, icon, sort_order, is_active, created_at, updated_at) VALUES
('Mobiles & Tablets','mobiles-tablets','both','📱',1,1,NOW(),NOW()),
('Vehicles','vehicles','both','🚗',2,1,NOW(),NOW()),
('Property','property','both','🏠',3,1,NOW(),NOW()),
('Electronics','electronics','both','💻',4,1,NOW(),NOW()),
('Home & Garden','home-garden','both','🛋️',5,1,NOW(),NOW());

INSERT IGNORE INTO users (id, name, email, phone, password, role, status, created_at, updated_at) VALUES
(1,'Kegalle','admin@kurulla.com','+94771234567','$2y$12$5sTDdcDC.g5hfTJmsHDSr.DhfuHKxQyQ.kFAFpW7xjExN6If5NMW6','admin','active',NOW(),NOW()),
(2,'Demo Seller','seller@kurulla.com','+94775551234','$2y$12$5sTDdcDC.g5hfTJmsHDSr.DhfuHKxQyQ.kFAFpW7xjExN6If5NMW6','user','active',NOW(),NOW());

INSERT IGNORE INTO stores (id,user_id,name,slug,description,phone,email,address,city,status,is_featured,created_at,updated_at) VALUES
(1,2,'TechZone Kegalle','techzone-kegalle','Mobile phones, laptops and accessories in Kegalle.','+94771234567','techzone@kurulla.com','Kegalle Town','Kegalle','approved',1,NOW(),NOW()),
(2,2,'Auto Hub Kegalle','auto-hub-kegalle','Trusted vehicle sellers in Kegalle.','+94775551234','auto@kurulla.com','Kegalle','Kegalle','approved',1,NOW(),NOW());

INSERT IGNORE INTO listings (user_id,store_id,category_id,title,slug,description,price,currency,type,status,is_featured,location,created_at,updated_at) VALUES
(2,1,1,'iPhone 13 Pro Max 256GB','iphone-13-pro-max-256gb','Excellent condition iPhone with warranty and accessories.',235000,'LKR','product','approved',1,'Kegalle',NOW(),NOW()),
(2,1,4,'Dell Core i5 Laptop 8GB RAM','dell-core-i5-laptop-8gb','Good condition laptop for office and student use.',85000,'LKR','product','approved',1,'Kegalle',NOW(),NOW()),
(2,2,2,'Toyota Aqua 2018 Hybrid','toyota-aqua-2018-hybrid','Well maintained Toyota Aqua hybrid car.',6250000,'LKR','classified','approved',1,'Kegalle',NOW(),NOW()),
(2,NULL,3,'Modern Apartment for Rent in Kegalle','modern-apartment-for-rent-kegalle','Two bedroom apartment available for rent in Kegalle town.',45000,'LKR','classified','approved',1,'Kegalle',NOW(),NOW());
